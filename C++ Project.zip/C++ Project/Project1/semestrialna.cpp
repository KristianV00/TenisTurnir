#include <iostream>
#include <string>
#include<sstream>
using namespace std;

struct Igrach {
	string ime, familia, durjava;
	string nomerVTurnira, nomerVRankListata;
	string tekushtiTochki, broiKupiPurvoMqsto;
};
struct Dvuboi {
	Igrach sustezatel1;
	Igrach sustezatel2;
	Igrach pobeditelVDvuboi;
	int rezultatSustezatel1 = 0;
	int rezultatSustezatel2 = 0;
};
void dobavqne_sustezatel(Igrach i[], int size);
void dobavqne_spisukSustezateli(Igrach i[], int size);
void izvejdane_sustezateli(Igrach i[], int size);
void izvejdane_naiMalkoKupi(Igrach i[], int counter);
void izvejdane_otDurjava(Igrach i[], int counter);
void proverka_danni(Igrach i[], int counter);
void proverka_sustezateli(Igrach i[], int counter);
void dvuboi(Dvuboi d[], int sizeDvuboi, Igrach i[], int counter);
void sortirane_NomerVRankLista(Igrach i[], int counter);
void sortirane_Durjavi_AzbuchenRed(Igrach i[], int counter);
void sortirane_BroiSpecheleniKupi_NamalqvashtRed(Igrach i[], int counter);

int counter = 0;

int main() {

	const int size = 100;
	Igrach i[size];
	const int sizeDvuboi = 2;
	Dvuboi d[sizeDvuboi];

	int select;
	do {
		cout << "1. Dobavqne na nov sustezatel" << endl;
		cout << "2. Dobavqne na spisuk sus sustezateli" << endl;
		cout << "3. Izvejdane na vsichki sustezateli" << endl;
		cout << "4. Izvejdane na sustezateli s nai malko specheleni kupi" << endl;
		cout << "5. Izvejdane na sustezateli ot opredelena durjava" << endl;
		cout << "6. Sustqvane na turniri" << endl;
		cout << "7. Odit na sustezatelite" << endl;
		cout << "8. Exit" << endl;
		cout << "Izberete opciq ot menuto: ";
		cin >> select;
		cin.ignore();
		cout << endl;
		switch (select) {
		case 1:
			dobavqne_sustezatel(i, size);
			cout << endl;
			break;
		case 2:
			if (counter < size) {
				dobavqne_spisukSustezateli(i, size);
			}
			else {
				cout << "Dostignahte limita za dobavqne na sustezateli." << endl;
			}
			cout << endl;
			break;
		case 3:
			izvejdane_sustezateli(i, size);
			cout << endl;
			break;
		case 4:
			izvejdane_naiMalkoKupi(i, counter);
			cout << endl;
			break;
		case 5:
			izvejdane_otDurjava(i, counter);
			cout << endl;
			break;
		case 6:
			dvuboi(d, sizeDvuboi, i, counter);
			break;
		case 7:
			int opciqPodMenu;
			bool izlizaneOtPodMenu = false;
			do {
			cout << "1. Izvejdane na sustezateli sortirani po nomer v Svetovnata ranklistata" << endl;
			cout << "2. Izvejdane na vsichki sustezateli ot dadena durjava sortirani po azbuchen red" << endl;
			cout << "3. Izvejdane na vsichki sustezateli ot dadena durjava sortirani po broi specheleni kupi v namalqvasht red" << endl;
			cout << "4. Izlizane ot podmenu" << endl;
			cout << "Izberete opciq: ";
			cin >> opciqPodMenu;
			cout << endl;
				switch (opciqPodMenu) {
				case 1:
					sortirane_NomerVRankLista(i, counter);
					break;
				case 2:
					sortirane_Durjavi_AzbuchenRed(i, counter);
					break;
				case 3:
					sortirane_BroiSpecheleniKupi_NamalqvashtRed(i, counter);
					break;
				case 4:
					izlizaneOtPodMenu = true;
					break;
				default:
					break;
				}
			} while (izlizaneOtPodMenu == false);
		}
	} while (select != 8);
	return 0;
}


void dobavqne_sustezatel(Igrach i[], int size) {
	char select;
	if (counter < size) {
		do {
			do {
				cout << "Ime: ";
				getline(cin, i[counter].ime);
				cout << "Familia: ";
				getline(cin, i[counter].familia);
				cout << "Durjava: ";
				getline(cin, i[counter].durjava);
				cout << "Nomer v turnira: ";
				getline(cin, i[counter].nomerVTurnira);
				proverka_sustezateli(i, counter);
				cout << "Nomer v ranklistata: ";
				getline(cin, i[counter].nomerVRankListata);
				cout << "Tekushti tochki: ";
				getline(cin, i[counter].tekushtiTochki);
				cout << "Broi kupi purvo mqsto: ";
				getline(cin, i[counter].broiKupiPurvoMqsto);
				proverka_danni(i, counter);	//proverqva dali lipsvat danni na sustezatelq
				do {
					cout << endl;
					cout << "Jelaete li da dobavite oshte edin igrach? --- Y/N" << endl;
					cout << "Vuvedete Y ili N: ";
					cin >> select;
					cin.ignore();
					cout << endl;
					if (select != 'Y' && select != 'N') {
						cout << "Wrong input" << endl;
					}
				} while (select != 'Y' && select != 'N');
			} while (select != 'Y' && select != 'N' && counter < size);

			counter++;
			if (counter == size && select != 'N') {
				cout << "Dostignahte limita za dobavqne na sustezateli." << endl;
			}
		} while (select != 'N' && counter < size);
	}
	else {
		cout << "Dostignahte limita za dobavqne na sustezateli." << endl;
	}
}
void dobavqne_spisukSustezateli(Igrach i[], int size) {
	int list;
	cout << "Dobavete list ot sustezateli: ";
	cin >> list;
	cin.ignore();
	if ((counter + list) <= size) {
		for (int a = 0; a < list; a++) {
			cout << endl;
			cout << "Ime: ";
			getline(cin, i[counter + a].ime);
			cout << "Familia: ";
			getline(cin, i[counter + a].familia);
			cout << "Durjava: ";
			getline(cin, i[counter + a].durjava);
			cout << "Nomer v turnira: ";
			getline(cin, i[counter + a].nomerVTurnira);
			proverka_sustezateli(i, counter + a);
			cout << "Nomer v ranklistata: ";
			getline(cin, i[counter + a].nomerVRankListata);
			cout << "Tekushti tochki: ";
			getline(cin, i[counter + a].tekushtiTochki);
			cout << "Broi kupi purvo mqsto: ";
			getline(cin, i[counter + a].broiKupiPurvoMqsto);
			cout << endl;
			proverka_danni(i, counter + a);
		}
		counter = counter + list;
	}
	else {
		cout << "Previshavate maksimalniq broi sustezateli" << endl;
	}
}
void izvejdane_sustezateli(Igrach i[], int size) {
	for (int a = 0; a < counter; a++) {
		cout << endl;
		cout << "Ime: " << i[a].ime << endl;
		cout << "Familia: " << i[a].familia << endl;
		cout << "Durjava: " << i[a].durjava << endl;
		cout << "Nomer v turnira: " << i[a].nomerVTurnira << endl;
		cout << "Nomer v ranklistata: " << i[a].nomerVRankListata << endl;
		cout << "Tekushti tochki: " << i[a].tekushtiTochki << endl;
		cout << "Broi kupi purvo mqsto: " << i[a].broiKupiPurvoMqsto << endl;
	}
}
void izvejdane_naiMalkoKupi(Igrach i[], int counter) {
	stringstream toInt(i[0].broiKupiPurvoMqsto);
	int convert = 0;
	toInt >> convert;
	int temp = convert;
	for (int a = 0; a < counter; a++) {
		stringstream toInt(i[a].broiKupiPurvoMqsto);
		toInt >> convert;
		if (temp > convert) {
			temp = convert;
		}
	}
	cout << "Igrachite s nai malko specheleni kupi sa: " << endl;
	for (int a = 0; a < counter; a++) {
		stringstream toInt(i[a].broiKupiPurvoMqsto);
		int convert = 0;
		toInt >> convert;
		if (convert == temp) {
			cout << i[a].ime << " " << i[a].familia << " s " << i[a].broiKupiPurvoMqsto << " kupi." << endl;
		}
	}
}
void izvejdane_otDurjava(Igrach i[], int counter) {
	cout << "Vuvedete durjava: ";
	string durjava;
	bool proverka = false; //shte proverqva dali ima sustezatel ot tazi durjava.
	cin >> durjava;
	cout << endl;
	for (int a = 0; a < counter; a++) {
		if (i[a].durjava == durjava) {
			cout << i[a].ime << " "<< i[a].familia << " e ot " << durjava << endl;
			proverka = true;
		}
	}
	if (proverka == false) {
		cout << "Nqma sustezatel ot takava durjava" << endl;
	}
}
void proverka_danni(Igrach i[], int counter) {
	bool lipsvatDanni = false;  //shte proverqva dali lipsvat danni.
	do {
		if (i[counter].ime.empty() 
			|| i[counter].familia.empty() 
			|| i[counter].durjava.empty() 
			|| i[counter].nomerVTurnira.empty() 
			|| i[counter].nomerVRankListata.empty() 
			|| i[counter].tekushtiTochki.empty() 
			|| i[counter].broiKupiPurvoMqsto.empty()) 
		{
			cout << endl << "Lipsvat danni." << endl;
			cout << "Molq vuvedete dannite nanovo." << endl << endl;
			cout << "Ime: ";
			getline(cin, i[counter].ime);
			cout << "Familia: ";
			getline(cin, i[counter].familia);
			cout << "Durjava: ";
			getline(cin, i[counter].durjava);
			cout << "Nomer v turnira: ";
			getline(cin, i[counter].nomerVTurnira);
			proverka_sustezateli(i, counter);
			cout << "Nomer v ranklistata: ";
			getline(cin, i[counter].nomerVRankListata);
			cout << "Tekushti tochki: ";
			getline(cin, i[counter].tekushtiTochki);
			cout << "Broi kupi purvo mqsto: ";
			getline(cin, i[counter].broiKupiPurvoMqsto);
			lipsvatDanni = true;
		}
		else {
			lipsvatDanni = false;
		}
	} while (lipsvatDanni == true);
}
void proverka_sustezateli(Igrach i[], int counter) {
	if (counter > 0) {
		bool imaTakuvNomer;
		for (int a = 0; a < counter; a++) {
			if (i[counter].nomerVTurnira == i[a].nomerVTurnira) {
				do {
					imaTakuvNomer = false;
					cout << "Veche sushtestvuva sustezatel s takuv nomer. Vuvedete otnovo." << endl;
					cout << "Nomer v turnira: ";
					getline(cin, i[counter].nomerVTurnira);
					for (int a = 0; a < counter; a++) {
						if (i[counter].nomerVTurnira == i[a].nomerVTurnira) {
							imaTakuvNomer = true;
						}
					}
				} while (imaTakuvNomer == true);
			}
		}
	}
}
void dvuboi(Dvuboi d[], int sizeDvuboi, Igrach i[], int counter) {

	for (int a = 0; a < sizeDvuboi; a++) {
		bool sushtestvuvaTakuvNomer = false;
		cout << endl;
		//vuvejdane na 1ri sustezatel ot dvuboq
		cout << "Vuvedete nomera v turnira 1-viq sustezatel v dvuboq: ";
		cin >> d[a].sustezatel1.nomerVTurnira;
		for (int j = 0; j < counter; j++) {
			if (d[a].sustezatel1.nomerVTurnira == i[j].nomerVTurnira) {
				sushtestvuvaTakuvNomer = true;
				d[a].sustezatel1.ime = i[j].ime;
				d[a].sustezatel1.familia = i[j].familia;
			}
		}
		while (sushtestvuvaTakuvNomer == false) {
			cout << "Ne sushtestvuva sustezatel s takuv nomer." << endl;
			cout << "Vuvedete otnovo nomera v turnira na 1-viq sustezatel v dvuboq: ";
			cin >> d[a].sustezatel1.nomerVTurnira;
			cout << endl;
			for (int j = 0; j < counter; j++) {
				if (d[a].sustezatel1.nomerVTurnira == i[j].nomerVTurnira) {
					d[a].sustezatel1.ime = i[j].ime;
					d[a].sustezatel1.familia = i[j].familia;
					sushtestvuvaTakuvNomer = true;
				}
			}
		}
		sushtestvuvaTakuvNomer = false;
		//vuvejdane na 2ri sustezatel ot dvuboq
		cout << "Vuvedete nomera v turnira na 2-riq sustezatel v dvuboq: ";
		cin >> d[a].sustezatel2.nomerVTurnira;
		for (int j = 0; j < counter; j++) {
			if (d[a].sustezatel2.nomerVTurnira == i[j].nomerVTurnira) {
				sushtestvuvaTakuvNomer = true;
				d[a].sustezatel2.ime = i[j].ime;
				d[a].sustezatel2.familia = i[j].familia;
			}
		}
		while (sushtestvuvaTakuvNomer == false) {
			cout << "Ne sushtestvuva sustezatel s takuv nomer." << endl;
			cout << "Vuvedete otnovo nomera v turnira na 2-riq sustezatel v dvuboq: ";
			cin >> d[a].sustezatel2.nomerVTurnira;
			cout << endl;
			for (int j = 0; j < counter; j++) {
				if (d[a].sustezatel2.nomerVTurnira == i[j].nomerVTurnira) {
					sushtestvuvaTakuvNomer = true;
					d[a].sustezatel2.ime = i[j].ime;
					d[a].sustezatel2.familia = i[j].familia;
				}
			}
		}

		cout << "Vuvedete rezultata ot macha." << endl;
		cout << "Vuvedete spechelenite setove na sustezatel 1 v dvuboq: ";
		cin >> d[a].rezultatSustezatel1;
		cout << "Vuvedete spechelenite setove na sustezatel 2 v dvuboq: ";
		cin >> d[a].rezultatSustezatel2;
		cout << "Uspeshno vuvedohte dvuboi." << endl << endl;
	}
	for (int a = 0; a < sizeDvuboi; a++) {
		cout << "Dvuboi " << a + 1 << endl;
		cout << "Sustezatel s nomer v turnira: " << d[a].sustezatel1.nomerVTurnira << " - " << d[a].sustezatel1.ime << " " << d[a].sustezatel1.familia;
		cout << endl;
		cout << "Sustezatel s nomer v turnira: " << d[a].sustezatel2.nomerVTurnira << " - " << d[a].sustezatel2.ime << " " << d[a].sustezatel2.familia;
		cout << endl;
		cout << "Rezultat - ";
		cout << d[a].sustezatel1.ime << " " << d[a].sustezatel1.familia << " vs " << d[a].sustezatel2.ime << " " << d[a].sustezatel2.familia << ": ";
		cout << d[a].rezultatSustezatel1 << " - " << d[a].rezultatSustezatel2 << endl;
		
		if (d[a].rezultatSustezatel1 > d[a].rezultatSustezatel2) {
			d[a].pobeditelVDvuboi.ime = d[a].sustezatel1.ime;
			d[a].pobeditelVDvuboi.nomerVTurnira = d[a].sustezatel1.nomerVTurnira;
		}
		if (d[a].rezultatSustezatel2 > d[a].rezultatSustezatel1) {
			d[a].pobeditelVDvuboi.ime = d[a].sustezatel2.ime;
			d[a].pobeditelVDvuboi.nomerVTurnira = d[a].sustezatel2.nomerVTurnira;
		}
		cout << "POBEDITEL - " << d[a].pobeditelVDvuboi.ime << " " << d[a].pobeditelVDvuboi.familia << endl << endl;
	}
}
void sortirane_NomerVRankLista(Igrach i[], int counter) {
	int temp; 
	int arr[100];

	for (int a = 0; a < counter; a++) {
		stringstream toInt(i[a].nomerVRankListata);
		toInt >> arr[a];
	}
	for (int a = 0; a < counter; a++) {		
		for (int j = a + 1; j < counter; j++) {
			if (arr[a] > arr[j]) {				
				temp = arr[a];
				arr[a] = arr[j];
				arr[j] = temp;
			}
		}
	}
	for (int a = 0; a < counter; a++) {		
		for (int j = 0; j < counter; j++) {
			stringstream toInt(i[j].nomerVRankListata);
			int nomerVRankLista;
			toInt >> nomerVRankLista;
			if (arr[a] == nomerVRankLista) {
				cout << i[j].nomerVRankListata << " nomer v ranklista: "; 
				cout << i[j].ime << " " << i[j].familia << " - " << i[j].nomerVTurnira << " nomer v turnira" << endl;
			}
		}
	}
}
void sortirane_Durjavi_AzbuchenRed(Igrach i[], int counter) {
	string temp;
	string inputDurjava;
	string arr[100];
	
	cout << "Izberete durjava: ";
	cin >> inputDurjava;

	for (int a = 0; a < counter; a++) {
		arr[a] = i[a].ime;
	}
	for (int a = 0; a < counter; a++) {
		for (int j = a + 1; j < counter; j++) {
			if (arr[a] > arr[j]) {
				temp = arr[a];
				arr[a] = arr[j];
				arr[j] = temp;
			}
		}
	}
	for (int a = 0; a < counter; a++) {
		for(int j = 0; j<counter;j++){
			if (i[j].durjava == inputDurjava && i[j].ime == arr[a]) {
			cout << i[j].ime << " ot " << inputDurjava << endl;
			}
		}
	}
	cout << endl;
}
void sortirane_BroiSpecheleniKupi_NamalqvashtRed(Igrach i[], int counter) {
	int temp;
	int arr[100];
	string inputDurjava;
	cout << "Izberete durjava: ";
	cin >> inputDurjava;

	for (int a = 0; a < counter; a++) {
		stringstream toInt(i[a].broiKupiPurvoMqsto);
		toInt >> arr[a];
	}
	for (int a = 0; a < counter; a++) {
		for (int j = a + 1; j < counter; j++) {
			if (arr[a] < arr[j]) {
				temp = arr[a];
				arr[a] = arr[j];
				arr[j] = temp;
			}
		}
	}
	for (int a = 0; a < counter; a++) {
		for (int j = 0; j < counter; j++) {
			stringstream toInt(i[j].broiKupiPurvoMqsto);
			int KupiPurvoMqsto;
			toInt >> KupiPurvoMqsto;
			if ((arr[a] == KupiPurvoMqsto) && (i[j].durjava == inputDurjava)) {
				cout << i[j].ime << " " << i[j].familia << " ot " << inputDurjava << " sus: " << i[j].broiKupiPurvoMqsto << " broi kupi" << endl;
			}
		}
	}
	cout << endl;
}

